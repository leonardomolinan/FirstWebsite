import { Component } from '@angular/core';

import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-modal',
  templateUrl: './Modal.component.html',
  styleUrls: ['./Modal.component.css']
})
export class ModalComponent {

}
