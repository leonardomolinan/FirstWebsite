package com.neppo.estagio.service.login;

public interface LoginService {

    boolean login(String username, String password);

}
