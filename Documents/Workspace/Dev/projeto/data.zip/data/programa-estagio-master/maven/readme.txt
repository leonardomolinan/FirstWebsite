Official site (conteúdo extraído deste site):
    https://maven.apache.org/guides/

Maven download:
    https://maven.apache.org/download.cgi

Archetypes:
	https://maven.apache.org/guides/introduction/introduction-to-archetypes.html

Commands:
    mvn archetype:generate -DarchetypeArtifactId=maven-archetype-quickstart

    mvn archetype:generate -DarchetypeArtifactId=jersey-quickstart-webapp -DarchetypeGroupId=org.glassfish.jersey.archetypes -DinteractiveMode=false -DgroupId=com.example -DartifactId=simple-service-webapp -Dpackage=com.example -D^CchetypeVersion=2.25.1

Tomcat download:
    http://tomcat.apache.org/download-80.cgi
